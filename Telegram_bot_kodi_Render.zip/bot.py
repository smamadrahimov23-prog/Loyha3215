import asyncio
import hashlib
import html
import logging
import os
import re
import shutil
import tempfile
import uuid
from pathlib import Path

import yt_dlp
from aiogram import BaseMiddleware, Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.filters import CommandStart
from aiogram.types import (
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from aiogram.webhook.aiohttp_server import SimpleRequestHandler, setup_application
from aiohttp import web
from shazamio import Shazam

# ================== SOZLAMALAR (Render Environment orqali) ==================
BOT_TOKEN = os.environ["BOT_TOKEN"]  # Render > Environment ga yoziladi
CHANNEL = os.getenv("CHANNEL", "@uzbek1ston_news")
CHANNEL_URL = os.getenv("CHANNEL_URL", "https://t.me/uzbek1ston_news")
BASE_URL = os.getenv("RENDER_EXTERNAL_URL") or os.getenv("WEBHOOK_BASE_URL")
PORT = int(os.getenv("PORT", "10000"))
WEBHOOK_PATH = "/webhook"
WEBHOOK_SECRET = hashlib.sha256(BOT_TOKEN.encode()).hexdigest()[:32]
MAX_SIZE = 49 * 1024 * 1024  # Telegram Bot API limiti ~50MB
MAX_PARALLEL = int(os.getenv("MAX_PARALLEL", "2"))  # Render free: 512MB RAM
# ===========================================================================

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("bot")

URL_RE = re.compile(
    r"(https?://[^\s]*(?:instagram\.com|youtube\.com|youtu\.be|facebook\.com|fb\.watch|fb\.com|tiktok\.com)[^\s]*)",
    re.I,
)

START_TEXT = (
    "👋✨ Salom men Izlovchibotman!\n\n"
    "💎 Mening xususiyatlarim bilan tanishing:\n\n"
    "• Qo'shiq matni, nomi yoki ijrochi ismi orqali musiqa topaman\n\n"
    "• Instagram, Youtube va Tik-Tokdan video va undagi musiqani yuklab beraman\n\n"
    "• Bundan tashqari men ovozli xabar, video va audiodagi musiqani to'liq shaklda topib beraman\n\n"
    "🚀 Qisqasi, izlash — mening ishim.\n\n"
    "👇 Video linkini yoki qo'shiq nomini yuboring!"
)

SUB_TEXT = (
    "❌ Siz obuna bo'lmagansiz!\n\n"
    "Botdan foydalanish uchun avval kanalimizga obuna bo'ling, "
    "so'ng «Tekshirish» tugmasini bosing 👇"
)

session = AiohttpSession(timeout=300)  # katta videolarni yuborish uchun
bot = Bot(BOT_TOKEN, session=session, default=DefaultBotProperties(parse_mode="HTML"))
dp = Dispatcher()
shazam = Shazam()
sem = asyncio.Semaphore(MAX_PARALLEL)
CACHE: dict[str, str] = {}  # qisqa id -> url


def prepare_cookies():
    """Render 'Secret Files' dagi cookies.txt ni yozish mumkin bo'lgan joyga ko'chiradi."""
    for p in (os.getenv("COOKIES_FILE", ""), "/etc/secrets/cookies.txt", "cookies.txt"):
        if p and os.path.exists(p):
            dst = "/tmp/cookies.txt"
            shutil.copy(p, dst)
            return dst
    return None


COOKIES = prepare_cookies()


def put(url: str) -> str:
    if len(CACHE) > 5000:
        CACHE.clear()
    key = uuid.uuid4().hex[:10]
    CACHE[key] = url
    return key


# ---------------- Majburiy obuna ----------------
async def is_subscribed(user_id: int) -> bool:
    try:
        m = await bot.get_chat_member(CHANNEL, user_id)
        return m.status not in ("left", "kicked")
    except Exception as e:
        log.error("Obunani tekshirib bo'lmadi (bot kanalda admin emasmi?): %s", e)
        return False


def sub_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📢 Obuna bo'lish", url=CHANNEL_URL)],
            [InlineKeyboardButton(text="✅ Tekshirish", callback_data="check_sub")],
        ]
    )


class SubMiddleware(BaseMiddleware):
    async def __call__(self, handler, event, data):
        user = data.get("event_from_user")
        if user and not (isinstance(event, CallbackQuery) and event.data == "check_sub"):
            if not await is_subscribed(user.id):
                if isinstance(event, Message):
                    await event.answer(SUB_TEXT, reply_markup=sub_kb())
                elif isinstance(event, CallbackQuery):
                    await event.answer("❌ Siz obuna bo'lmagansiz!", show_alert=True)
                    await event.message.answer(SUB_TEXT, reply_markup=sub_kb())
                return
        return await handler(event, data)


dp.message.outer_middleware(SubMiddleware())
dp.callback_query.outer_middleware(SubMiddleware())


@dp.callback_query(F.data == "check_sub")
async def check_sub(call: CallbackQuery):
    if await is_subscribed(call.from_user.id):
        try:
            await call.message.delete()
        except Exception:
            pass
        await call.message.answer(START_TEXT)
        await call.answer()
    else:
        await call.answer("❌ Siz hali obuna bo'lmagansiz!", show_alert=True)


# ---------------- Yuklash funksiyalari (sinxron, thread ichida) ----------------
def base_opts(out_dir: str) -> dict:
    o = {
        "outtmpl": f"{out_dir}/%(id)s.%(ext)s",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "socket_timeout": 30,
        "retries": 3,
        "concurrent_fragment_downloads": 4,
    }
    if COOKIES:
        o["cookiefile"] = COOKIES
    return o


def find_file(out_dir: str, vid: str, exts) -> Path | None:
    for ext in exts:
        p = Path(out_dir) / f"{vid}.{ext}"
        if p.exists():
            return p
    return None


def dl_video(url: str, out_dir: str):
    """1080p dan boshlaydi, 50MB dan oshsa pastroq sifatga tushadi."""
    info = None
    for h in (1080, 720, 480, 360):
        opts = base_opts(out_dir)
        opts.update(
            {
                "format": (
                    f"bestvideo[height<={h}][vcodec^=avc1]+bestaudio[ext=m4a]/"
                    f"bestvideo[height<={h}]+bestaudio/best[height<={h}]/best"
                ),
                "merge_output_format": "mp4",
            }
        )
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
        if "entries" in info:
            info = info["entries"][0]
        path = find_file(out_dir, info["id"], ("mp4", "mkv", "webm", "mov"))
        if path and path.stat().st_size <= MAX_SIZE:
            return path, info
        if path:
            path.unlink()
    return None, info


def dl_audio(target: str, out_dir: str):
    opts = base_opts(out_dir)
    opts.update(
        {
            "format": "bestaudio/best",
            "postprocessors": [
                {"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}
            ],
        }
    )
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(target, download=True)
        if "entries" in info:
            info = info["entries"][0]
    path = Path(out_dir) / f"{info['id']}.mp3"
    if not path.exists():
        raise FileNotFoundError("mp3 yaratilmadi")
    return path, info


def yt_search(query: str, n: int = 8):
    opts = {"quiet": True, "no_warnings": True, "extract_flat": True, "socket_timeout": 30}
    if COOKIES:
        opts["cookiefile"] = COOKIES
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(f"ytsearch{n}:{query}", download=False)
    return [e for e in (info.get("entries") or []) if e and e.get("id")]


async def trim_audio(src: str, dst: str, seconds: int = 25) -> str:
    """Shazam tezroq ishlashi uchun faqat boshidagi bir necha soniya olinadi."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "ffmpeg", "-y", "-i", src, "-t", str(seconds), "-vn", "-ac", "1", "-ar", "44100", dst,
            stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL,
        )
        await asyncio.wait_for(proc.wait(), timeout=60)
    except Exception as e:
        log.warning("ffmpeg trim xato: %s", e)
    return dst if os.path.exists(dst) else src


async def shazam_find(file_path: str, tmp: str):
    try:
        short = await trim_audio(file_path, os.path.join(tmp, "shazam.mp3"))
        res = await shazam.recognize(short)
        track = res.get("track")
        if track:
            return track.get("title"), track.get("subtitle")
    except Exception as e:
        log.warning("Shazam xato: %s", e)
    return None, None


async def send_full_song(msg: Message, title: str, artist: str, tmp: str):
    path, _ = await asyncio.to_thread(dl_audio, f"ytsearch1:{artist} - {title}", tmp)
    me = await bot.me()
    await msg.answer_audio(
        FSInputFile(path),
        title=title,
        performer=artist,
        caption=f"🎵 <b>{html.escape(artist)} — {html.escape(title)}</b>\n\n🤖 @{me.username}",
    )


# ---------------- Handlerlar ----------------
@dp.message(CommandStart())
async def start(m: Message):
    await m.answer(START_TEXT)


@dp.message(F.text.regexp(URL_RE))
async def link_handler(m: Message):
    url = URL_RE.search(m.text).group(1)
    wait = await m.answer("⏳ Yuklanmoqda...")
    async with sem:
        with tempfile.TemporaryDirectory() as tmp:
            try:
                path, info = await asyncio.to_thread(dl_video, url, tmp)
                if not path:
                    await wait.edit_text("❌ Video juda katta (50MB dan oshdi) yoki yuklab bo'lmadi.")
                    return
                me = await bot.me()
                kb = InlineKeyboardMarkup(
                    inline_keyboard=[
                        [InlineKeyboardButton(text="🎵 Qo'shiqni yuklab olish", callback_data=f"song:{put(url)}")]
                    ]
                )
                await m.answer_video(
                    FSInputFile(path),
                    width=info.get("width"),
                    height=info.get("height"),
                    duration=int(info.get("duration") or 0) or None,
                    supports_streaming=True,
                    caption=f"🤖 @{me.username}",
                    reply_markup=kb,
                )
                await wait.delete()
            except Exception as e:
                log.exception(e)
                await wait.edit_text("❌ Videoni yuklab bo'lmadi. Linkni tekshirib qayta yuboring.")


@dp.callback_query(F.data.startswith("song:"))
async def song_cb(call: CallbackQuery):
    url = CACHE.get(call.data.split(":", 1)[1])
    if not url:
        return await call.answer("Eskirgan tugma, linkni qayta yuboring.", show_alert=True)
    await call.answer("🎵 Qo'shiq izlanmoqda...")
    wait = await call.message.answer("🔎 Qo'shiq topilmoqda...")
    async with sem:
        with tempfile.TemporaryDirectory() as tmp:
            try:
                path, info = await asyncio.to_thread(dl_audio, url, tmp)
                title, artist = await shazam_find(str(path), tmp)
                if title:
                    await send_full_song(call.message, title, artist, tmp)
                else:
                    await call.message.answer_audio(
                        FSInputFile(path),
                        title=info.get("title"),
                        caption="ℹ️ Shazam qo'shiqni aniqlay olmadi, videodagi audio yuborildi.",
                    )
                await wait.delete()
            except Exception as e:
                log.exception(e)
                await wait.edit_text("❌ Qo'shiqni topib bo'lmadi.")


@dp.message(F.voice | F.audio | F.video | F.video_note)
async def media_handler(m: Message):
    media = m.voice or m.audio or m.video or m.video_note
    if media.file_size and media.file_size > 20 * 1024 * 1024:
        return await m.answer("❌ Fayl 20MB dan kichik bo'lishi kerak.")
    wait = await m.answer("🔎 Qo'shiq aniqlanmoqda...")
    async with sem:
        with tempfile.TemporaryDirectory() as tmp:
            try:
                src = os.path.join(tmp, "in.bin")
                await bot.download(media, destination=src)
                title, artist = await shazam_find(src, tmp)
                if not title:
                    return await wait.edit_text("😕 Qo'shiq topilmadi. Boshqa parcha yuboring.")
                await send_full_song(m, title, artist, tmp)
                await wait.delete()
            except Exception as e:
                log.exception(e)
                await wait.edit_text("❌ Xatolik yuz berdi. Qayta urinib ko'ring.")


@dp.message(F.text & ~F.text.startswith("/"))
async def search_handler(m: Message):
    wait = await m.answer("🔎 Izlanmoqda...")
    try:
        results = await asyncio.to_thread(yt_search, m.text)
        if not results:
            return await wait.edit_text("😕 Hech narsa topilmadi.")
        lines, buttons = [], []
        for i, r in enumerate(results, 1):
            dur = int(r.get("duration") or 0)
            lines.append(f"{i}. {html.escape(r.get('title') or '')} — {dur // 60}:{dur % 60:02d}")
            link = r.get("url") or f"https://www.youtube.com/watch?v={r['id']}"
            buttons.append(InlineKeyboardButton(text=str(i), callback_data=f"pick:{put(link)}"))
        kb = InlineKeyboardMarkup(inline_keyboard=[buttons[i:i + 4] for i in range(0, len(buttons), 4)])
        await wait.edit_text("\n".join(lines) + "\n\n👇 Kerakli raqamni tanlang", reply_markup=kb)
    except Exception as e:
        log.exception(e)
        await wait.edit_text("❌ Qidiruvda xatolik.")


@dp.callback_query(F.data.startswith("pick:"))
async def pick_cb(call: CallbackQuery):
    url = CACHE.get(call.data.split(":", 1)[1])
    if not url:
        return await call.answer("Eskirgan tugma, qayta qidiring.", show_alert=True)
    await call.answer("⏳ Yuklanmoqda...")
    async with sem:
        with tempfile.TemporaryDirectory() as tmp:
            try:
                path, info = await asyncio.to_thread(dl_audio, url, tmp)
                me = await bot.me()
                await call.message.answer_audio(
                    FSInputFile(path),
                    title=info.get("title"),
                    performer=info.get("uploader"),
                    caption=f"🤖 @{me.username}",
                )
            except Exception as e:
                log.exception(e)
                await call.message.answer("❌ Qo'shiqni yuklab bo'lmadi.")


# ---------------- Ishga tushirish ----------------
async def health(_request):
    return web.Response(text="Bot ishlayapti ✅")


async def on_startup(bot: Bot):
    url = f"{BASE_URL.rstrip('/')}{WEBHOOK_PATH}"
    await bot.set_webhook(
        url,
        secret_token=WEBHOOK_SECRET,
        drop_pending_updates=True,
        allowed_updates=dp.resolve_used_update_types(),
    )
    log.info("Webhook o'rnatildi: %s", url)


def main():
    if BASE_URL:
        # Render (webhook rejimi)
        dp.startup.register(on_startup)
        app = web.Application()
        app.router.add_get("/", health)
        SimpleRequestHandler(dispatcher=dp, bot=bot, secret_token=WEBHOOK_SECRET).register(
            app, path=WEBHOOK_PATH
        )
        setup_application(app, dp, bot=bot)
        web.run_app(app, host="0.0.0.0", port=PORT)
    else:
        # Kompyuterda sinash (polling rejimi)
        async def run():
            await bot.delete_webhook(drop_pending_updates=True)
            await dp.start_polling(bot)

        asyncio.run(run())


if __name__ == "__main__":
    main()
